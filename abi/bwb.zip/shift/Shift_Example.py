# -*- coding: utf-8 -*-
"""
中性策略框架 | 邢不行 | 2024分享会
author: 邢不行
微信: xbx6660
"""
import os

# 取出策略文件名中_后的部分
stg_name = os.path.basename(__file__).split('.')[0].split('_')[1]

# 配置子策略文件
# key为子策略文件名，value为一个列表，可以选择多空资金曲线、多头资金曲线、空头资金曲线
# 各个Strategy之间需要保证 hold_period和offset 保持一致
base_strategy_dict = {
    'Strategy_QuoteVolumeMean': ['多空资金曲线', '多头资金曲线'],
}

# 因子信息列表
factor_list = [('Bias', False, 7, 1)]  # 指定因子列表，可以配置多因子，和选币时的用法一致

# 选策略的数量
select_num = 1  # 指定选择策略的数量，指定的数量大于1时，不会生成第二张资金曲线图
